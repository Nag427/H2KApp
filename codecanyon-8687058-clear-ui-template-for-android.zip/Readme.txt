------------ Thank you for your purchase! -----------

To get started, open the documentation folder and open index.html

----------- License -------------

For more license information, check the License text file inside the template's folder.

------------ Content -----------

-template - contains actual template to import to eclipse
-documentation - contains documentation


